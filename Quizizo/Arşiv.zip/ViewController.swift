//
//  ViewController.swift
//  Quizizo
//
//  Created by MURAD on 1.10.2025.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
    }


}

